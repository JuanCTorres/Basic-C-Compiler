int main (void) {
/* ignore these!
	this too
 */

//same here

int a, b, c;
int d, e, f;
int h = 2, i = 3;
int cc[12], dd[5];


cc[a * b] = a * b;


print "test basics!\n";
read f;

c=1-b;

c=b +1;

//c=c-c;

c=5-5;
c=1*-6;
c=-2-9;
c=+1+7;
c=1 - -10;
c=22- -88;


c = a * -b;
c = a + b;
c = a - b;
c = a * b;
c = a / b;
c = a % b;
c = a < b;
c = a <= b;
c = a > b;
c = a >= b;
c = a == b;
c = a != b;
c = a && b;
c = a || b;
c = !b;
c = -b;
c = ++b;
c = --b;
c = (a % 5);
c = -23;


for(a = 100; a < 200; ++a) {
	int zz = -100;
	a + b;
	c = e + f;
}

while((a/5)-(-3 + -8) == 100) {
	int tt, uu[10];
	print(12 * 21);

}

do {
	int asd;
	int dsa;
	asd = dsa;
} while(1);

if(a*b == d) {
	int x;

} else {
	int y;
}

	return 0;
}
