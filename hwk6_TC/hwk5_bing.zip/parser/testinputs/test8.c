void this_func() {
}


int main(){
	return 0;
}
