int my_func(int q, int b) { //0
	print(q + b);	//1.0
	return 12345;
}

void your_func() {
	int gg, ee;		//1.1
	print "LOL!\n";
}

// void my_func(int g) {
// 	int mmm;
// }

int main(void) {	//0
					//1.2
	int a, t, y, u, w, v, ppp;	//1.2
	int fff[2];
	a = t= y = -(4/5);

	if(a > 10) { // 1.2
		//2.0
		if(1) { //2.0
			//3
			do { //3.0
				a = 3;
				a = 4;
				t = 3;
				a * t;
				// read input; //4
			} while (a * (t - u) / w != 10); //3.0
		}
		else{ //2.1
			print "not\n"; //3.1
		}

	}
	else { // 1.2
		// 2.1
		int qwert = 123; //2.1
		for(t = 0; t < 99; ++t) { // 2.1
			a = y = u; // 3.2
			y = a = w;
			print "in for loop\n";
		}
	}

	w = my_func(w, v); // 1.2
	your_func();
	my_func(fff[1], v + (y * t *(v - ppp)));						// 1.2


	return ((a + w) / ((t * ppp) - y - u - w) );
}
