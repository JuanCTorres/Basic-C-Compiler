
int this_func(int g) { // this func: 0, g: 0
	print "at this_func"; // 1.0
	return 0;							// 1.0
}

int main() {						// 0
												// 1.1
	if(1) 								// 1.1
	{
		int b = 3 ;					// 2.0
	}
	else {
		int a = 5;					// 2.1
		print "hello";
	}

	while(b > 1000){			// 1.1
		int aaa = -123;			// 2.2
		if(a+b) {						// 2.2
			int qwe = 0, av[123];	// 3.0
		}

	}


	do {												// 1.1
		for(  i = 0; i < z; ++i) {	// 2.3
			c = d = e = f;						// 3.1

		}
	} while (ab+c+d+e+f != 123); // 1.1

	d = 10;												// 1.1

	return ((a%2) * (5 - 13));		// 1.1
}
