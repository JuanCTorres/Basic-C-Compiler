void my_func(int a, int d){
	int e, f, g, h;
	e = f + 4;
	//return g;
}

void my_new_f(){
	int e;
}


int main(){

	int a, b, c, d;
	b = 1;
	c = 2;
	d = 3;

	if(a == 1){
		b = 1;
	}

	if(b == 1){
		c = 2;
		d = 4;
		a + b;
	} else{
		c = 3;
		b = 2;
		d = 1;
		a = d + b;
	}

	// // While
	//
	// while(c != 0){
	// 	d = 3;
	// }
	//
	// // Do while
	//
	do{
		a = 3;
	} while(b == 3);
	//
	// // For
	//
	// for(a = 3; a + 5; ++a){
	// 	b = 3;
	// }

	for(a = 3; ; ++a){
		b = 3;
		b = 3;
		b = 3;
		b = 3;
		b = 3;
		// b = 3;
		// b = 3;
		// b = 3;
		// a = 5;
		// a = 0;
	}
	print "alygljkglkug";

	my_func(b + 3 + d, c);


	d = 7;
	a + c;

	(d + b) == 2;

	a + b[3];

	a + b[5];


	return 0;
}
