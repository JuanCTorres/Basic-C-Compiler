void main(int a, int b, int c) {
	int zzzz;
	{
		int d;
		{
			int e;
			{
				int f;
				if(e != f) {
					int g;
					{
						int h;
						while(h != 0){
							int i;
							for(h;h>10;++h){
								int j;

							}
						}
					}
				}
			}
		}
	}

	{
		int huehuehue;
	}

	{
		int lolz, catz[100], haaa;

	}
}